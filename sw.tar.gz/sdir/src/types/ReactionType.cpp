#include "tgbot/types/ReactionTypeEmoji.h"
#include "tgbot/types/ReactionTypeCustomEmoji.h"

#include <string>

using namespace TgBot;

const std::string ReactionTypeEmoji::TYPE = "emoji";
const std::string ReactionTypeCustomEmoji::TYPE = "custom_emoji";
